"""Validate the evidence collection only. Does not run app/tests or edit originals.

Rebuilds generated manifest rows, link map, tree and validation.json inside this
collection. Byte-exact copy rows retain their source identity and recorded data.
"""
import collections
import csv
import datetime as dt
import hashlib
import json
import pathlib
import re
import subprocess
import urllib.parse
import xml.etree.ElementTree as ET

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent.parent
ROOT = OUT.parent.parent.parent
BASE = "bd9cc4340f67fb75d2db36a8294d66cfeda6b9a9"
MANIFEST = OUT / "evidence-manifest.csv"
RESULT = HERE / "validation.json"
FIELDS = ["Evidence ID", "Assignment responsibility", "Test case or requirement", "Description",
          "Original path", "New path", "Evidence type", "Execution date, if recorded", "Result or status",
          "Source commit or PR, if known", "Original contributor or tester", "SHA-256 hash", "Bytes",
          "Original last-write UTC", "Record kind"]

def git(*args):
    # Per-command option only; do not alter the user's local/global Git settings.
    return subprocess.check_output(["git", "-c", "core.longpaths=true", *args], cwd=ROOT).decode("utf-8").strip()

def sha(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

def write_json(p,data):
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def write_csv(p,rows,fields):
    with p.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader(); w.writerows(rows)

def links(path):
    # Repository Markdown links; inline code and code fences contain no links.
    body=path.read_text(encoding="utf-8-sig")
    for match in re.finditer(r"!?\[[^\]\n]*\]\((<[^>]+>|[^)\n]+)\)",body):
        value=match.group(1).strip().strip("<>")
        if not value.startswith(("http://","https://","mailto:","#","codex:")):
            clean=urllib.parse.unquote(value.split("#")[0].split("?")[0])
            yield value,(path.parent/clean).resolve()

def read_json(rel):
    return json.loads((OUT/rel).read_text(encoding="utf-8-sig"))

def main():
    baseline=read_json("08-Git-and-Contributions/verification/original-files-baseline.json")
    with MANIFEST.open(encoding="utf-8-sig",newline="") as f:
        reader=csv.DictReader(f)
        assert reader.fieldnames==FIELDS
        copies=[r for r in reader if r["Record kind"]=="Byte-exact copy"]
    # Storage provenance is separate from the state tested in original ledgers.
    latest={}; current=None
    for line in git("-c","core.quotepath=false","log","--no-merges","--format=@@@%H%x09%an","--name-only",BASE).splitlines():
        if line.startswith("@@@"):
            current=line[3:].split("\t")
        elif line and current:
            latest.setdefault(line,current)
    tracked=set(git("ls-files","-z").split("\0"))-{ "" }
    for path in {r["Original path"] for r in copies} & tracked:
        if path not in latest:
            # Some files were first added while resolving an integration merge.
            latest[path]=git("log","-1","--format=%H%x09%an",BASE,"--",path).split("\t")
            assert len(latest[path])==2, path
    exact_mapping={
        "DashboardEnhancementTests.cs":"SQA-10/11/12; TC-10; FR-07",
        "DashboardServiceTests.cs":"SQA-10/11/12; TC-10; FR-07",
        "DashboardPerformanceTests.cs":"SQA-17; PT-01; NFR-PERF-01 (aggregation/HTTP only; no browser execution)",
        "ReportsEnhancementTests.cs":"SQA-13/14/15/16/21; TC-11; FR-08",
        "ReportsControllerTests.cs":"SQA-15; TC-11; FR-08",
        "FailureMessageTests.cs":"SQA-19; TC-12; NFR-USA-01 (automated message support; not human acceptance)",
        "ApiCheckPipelineIntegrationTests.cs":"SQA-04/09/22; FR-03/FR-04/FR-06; NFR-REL-01 (SQA-22 is simulated transport)",
        "ApplicationStoreIsolationTests.cs":"Startup/store-isolation regression; supporting infrastructure; no separate master acceptance-case ID",
        "Pt01FixtureTests.cs":"SQA-17/18 fixture integrity; NFR-PERF-01 (fixture assertions; no browser execution)",
        "Pt01Fixture.cs":"SQA-17/18 deterministic fixture; NFR-PERF-01 (test data source)",
        "SecureApiQualityPlatform.Tests.csproj":"MSTest/coverage configuration; no standalone case result",
        "ReportsController.cs":"SQA-13/14/15/16/21; TC-11; FR-08",
        "DashboardService.cs":"SQA-10/11/12; TC-10; FR-07",
        "DashboardViewModel.cs":"SQA-10/11/12; TC-10; FR-07",
        "HomeController.cs":"SQA-10/11; TC-10; FR-07",
    }
    copy_errors=[]; time_errors=[]; by_original={}
    for r in copies:
        src=ROOT/r["Original path"]; dst=ROOT/r["New path"]
        if not src.is_file() or not dst.is_file() or sha(src)!=r["SHA-256 hash"] or sha(dst)!=r["SHA-256 hash"]:
            copy_errors.append(r["Evidence ID"])
        if src.is_file() and dst.is_file() and src.stat().st_mtime_ns!=dst.stat().st_mtime_ns:
            time_errors.append(r["Evidence ID"])
        if r["Original path"] in latest:
            r["Source commit or PR, if known"]="https://github.com/3ilmar/apiguard/commit/"+latest[r["Original path"]][0]
        path=r["Original path"]; name=pathlib.PurePosixPath(path).name
        if path.startswith(("SecureApiQualityPlatform.","tools/",".github/")):
            r["Original contributor or tester"]="Combined team source; last recorded Git author: "+latest.get(path,["","unknown"])[1]
        if path.startswith("tools/Sqa20.ManualHost/axe/") and name in ["axe.min.js","package.json","LICENSE"]:
            r["Original contributor or tester"]="Deque Systems and axe-core contributors (upstream MPL-2.0); vendored/pinned in Shirui's QA tooling"
        if name.startswith("network-attachment-") or name=="Trace-20261018T195043.json":
            r["Original contributor or tester"]="User-supplied browser capture; exact tester metadata not recorded; preserved/analysed with Codex assistance"
        if name in exact_mapping:
            r["Test case or requirement"]=exact_mapping[name]
        elif path.endswith("Views/Home/Index.cshtml"):
            r["Test case or requirement"]="SQA-10/11/12; FR-07; SQA-18/20 visual support"
        elif "SQA-20/" in path or path.startswith("tools/Sqa20."):
            r["Test case or requirement"]="Category relevance: SQA-20; NFR-USA-01; NFR-COMP-01 (not per-file full compliance)"
        else:
            r["Test case or requirement"]=r["Test case or requirement"].replace("FR07/08/09/11/12","FR-07; FR-08").replace("FR-07/FR-08/FR-09/FR-11/FR-12","FR-07; FR-08")
        if name=="numeric-endpoint-validation-assessment.md":
            r["Test case or requirement"]="PM-VALIDATION-01; FR-02; separate from SQA-19 approval"
        if name=="browser-execution.json":
            record=json.loads(src.read_text(encoding="utf-8-sig"))
            counts=dict(collections.Counter(item["status"] for item in record["results"]))
            r["Result or status"]="Recorded overall automated status: "+record["overallAutomatedStatus"]+"; category counts: "+json.dumps(counts)+"; human acceptance not performed"
            r["Execution date, if recorded"]=record["startedAtUtc"]+" to "+record["completedAtUtc"]
        r["Description"]=r["Evidence type"]+": "+r["Original path"]
        by_original[r["Original path"]]=dst
    original_errors=[]; original_time_errors=[]
    for r in baseline["baseline"]:
        p=ROOT/r["path"]
        if not p.is_file() or sha(p)!=r["sha256"]:
            original_errors.append(r["path"])
        elif p.stat().st_mtime_ns!=r["mtime_ns"]:
            original_time_errors.append(r["path"])
    link_rows=[]
    for r in copies:
        if pathlib.PurePosixPath(r["Original path"]).name.lower()!="readme.md": continue
        original=ROOT/r["Original path"]; copied=ROOT/r["New path"]
        for value,target in links(original):
            try: original_target=target.relative_to(ROOT).as_posix()
            except ValueError: original_target=str(target)
            mapped=by_original.get(original_target)
            copied_literal=(copied.parent/urllib.parse.unquote(value.split("#")[0].split("?")[0])).resolve()
            link_rows.append({"Original README":r["Original path"],"Copied README":r["New path"],
                "Original link":value,"Original target":original_target,"Original target exists":target.exists(),
                "Copied literal target exists":copied_literal.exists(),
                "Collected target":mapped.relative_to(ROOT).as_posix() if mapped else "",
                "Interpretation":"Original-relative link retained unchanged; use mapped/original target"})
    write_csv(HERE/"archived-readme-links.csv",link_rows,["Original README","Copied README","Original link",
        "Original target","Original target exists","Copied literal target exists","Collected target","Interpretation"])
    # Preserve original populations and explicit stage-specific outcomes.
    a11y="06-Accessibility-SQA20/docs/qa-evidence/SQA-20/"
    initial=read_json(a11y+"playwright-20261019T035608Z/browser-execution.json")
    before=read_json(a11y+"retest-20261019T095150Z/before/browser-execution.json")
    after=read_json(a11y+"retest-20261019T095150Z/after/browser-execution.json")
    def statuses(record):
        return dict(collections.Counter(r["status"] for r in record["results"]))
    initial_counts=statuses(initial); before_counts=statuses(before); after_counts=statuses(after)
    initial_readme=(OUT/a11y/"playwright-20261019T035608Z/README.md").read_text(encoding="utf-8-sig")
    assessment=(OUT/"05-Usability-SQA19/docs/qa-evidence/SQA-19/observer-assessment-session-eilmar.md").read_text(encoding="utf-8-sig")
    with (OUT/"07-Quality-Metrics/docs/ShiruiFinalTestCases.csv").open(encoding="utf-8-sig",newline="") as f:
        register=list(csv.DictReader(f))
    master_counts=dict(collections.Counter(r["Status"] for r in register))
    ns={"t":"http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}
    trx=ET.parse(OUT/a11y/"retest-20261019T095150Z/postfix-suite/postfix.trx")
    mstest=trx.find(".//t:Counters",ns).attrib
    http=read_json(a11y+"retest-20261019T095150Z/postfix-http-verified/summary.json")
    anchors={"initial_sqa20_technical_16_pass":initial_counts=={"PASS":16},
             "initial_sqa20_overall_fail_ledger_retained":"FAIL" in initial_readme and initial["overallAutomatedStatus"]=="FAIL",
             "before_sqa20_14_pass_2_fail":before_counts=={"PASS":14,"FAIL":2},
             "after_sqa20_16_pass":after_counts=={"PASS":16} and after["overallAutomatedStatus"]=="PASS",
             "sqa19_final_observer_approval":"observer approved" in assessment and "5/5" in assessment,
             "human_submission_copied":"docs/qa-evidence/SQA-19/observation-sheet-session-eilmar.md" in by_original,
             "master_22_16_pass_6_not_run":len(register)==22 and master_counts=={"PASS":16,"NOT RUN":6},
             "historical_mstest_136_pass":mstest.get("total")=="136" and mstest.get("passed")=="136" and mstest.get("failed")=="0",
             "http_failure_retained":http["passed"]==28 and http["failed"]==1 and http["status"]=="FAIL"}
    # The tree includes forthcoming self-index/verification output paths.
    expected={p.relative_to(OUT).as_posix() for p in OUT.rglob("*") if p.is_file()}
    expected.update(["08-Git-and-Contributions/verification/directory-tree.txt","08-Git-and-Contributions/verification/validation.json"])
    tree=["docs/evidence/Shirui/"]+["  "+path for path in sorted(expected)]
    (HERE/"directory-tree.txt").write_text("\n".join(tree)+"\n",encoding="utf-8")
    generated=[]
    copy_paths={r["New path"] for r in copies}
    for relative in sorted(expected):
        p=OUT/relative
        repo_path=p.relative_to(ROOT).as_posix()
        if repo_path in copy_paths: continue
        self_record=p in [MANIFEST,RESULT]
        source="Generated during evidence consolidation; no historical original"
        if p.name=="github-pr-snapshots.json":source="GitHub API: https://github.com/3ilmar/apiguard/pull/{2,5,7,12,13} and their reviews/comments"
        elif p.parent.name=="git": source="Local Git export at baseline "+BASE
        generated.append({"Evidence ID":f"SH-G{len(generated)+1:03}","Assignment responsibility":"Evidence index/provenance/integrity; T9/T11 inputs",
            "Test case or requirement":"Collection validation only; not application test execution",
            "Description":relative,"Original path":source,"New path":repo_path,"Evidence type":"Generated collection record",
            "Execution date, if recorded":"Not an application test execution; see collection/validation UTC timestamps",
            "Result or status":"Self-index/current verification output; self-hash/size omitted" if self_record else "Generated from inspected source evidence; not a new historical result",
            "Source commit or PR, if known":BASE,"Original contributor or tester":"Codex-assisted evidence consolidation requested by Shirui",
            "SHA-256 hash":"" if self_record else sha(p),"Bytes":"" if self_record else p.stat().st_size,
            "Original last-write UTC":"Not applicable (new record)","Record kind":"Generated record"})
    write_csv(MANIFEST,copies+generated,FIELDS)
    readme_errors=[]; readme_links=0
    for value,target in links(OUT/"README.md"):
        readme_links+=1
        # The current verification file is written below on this same run.
        if not target.exists() and target!=RESULT: readme_errors.append(value)
    missing_manifest_files=[r["New path"] for r in copies+generated if not (ROOT/r["New path"]).is_file() and (ROOT/r["New path"])!=RESULT]
    diff_names=git("diff","--name-only",BASE).splitlines()
    new_files=git("ls-files","--others","--exclude-standard","-z").split("\0")
    outside_new=[p for p in new_files if p and not p.startswith("docs/evidence/Shirui/")]
    ignored=git("ls-files","--others","--ignored","--exclude-standard","-z","--","docs/evidence/Shirui").split("\0")
    ignored=[p for p in ignored if p]
    manifest_provenance_errors=[r["Original path"] for r in copies
        if r["Original path"] in tracked and not r["Source commit or PR, if known"].startswith("https://github.com/3ilmar/apiguard/commit/")]
    known_requirements=set(re.findall(r"\b(?:FR|NFR-[A-Z]+)-\d{2}\b",(ROOT/"docs/Requirements.md").read_text(encoding="utf-8-sig")))
    requirement_errors=sorted({req for r in copies for req in re.findall(r"\b(?:FR|NFR-[A-Z]+)-\d{2}\b",r["Test case or requirement"]) if req not in known_requirements})
    generated_hash_errors=[r["New path"] for r in generated if r["SHA-256 hash"] and sha(ROOT/r["New path"])!=r["SHA-256 hash"]]
    branch=git("branch","--show-current")
    integrity=not(copy_errors or time_errors or original_errors or original_time_errors or readme_errors or missing_manifest_files or diff_names or outside_new or ignored or manifest_provenance_errors or requirement_errors or generated_hash_errors)
    passed=integrity and all(anchors.values()) and git("rev-parse","HEAD")==BASE and branch=="codex/shirui-assignment2-evidence"
    result={"validated_at_utc":dt.datetime.now(dt.timezone.utc).isoformat(),"client_timezone":"Pacific/Auckland",
        "status":"PASS" if passed else "FAIL","validation_scope":"Evidence collection integrity only; no application/browser/HTTP tests rerun",
        "baseline_commit":BASE,"branch":branch,"copied_files":len(copies),"copied_bytes":sum(int(r["Bytes"]) for r in copies),
        "generated_files":len(generated),"manifest_records":len(copies)+len(generated),
        "preexisting_files_checked":len(baseline["baseline"]),"copy_hash_errors":copy_errors,"copy_timestamp_errors":time_errors,
        "original_content_changes":original_errors,"original_timestamp_changes":original_time_errors,
        "new_readme_local_links_checked":readme_links,"new_readme_broken_links":readme_errors,
        "historical_readme_links_audited":len(link_rows),
        "historical_original_links_unavailable":sum(not r["Original target exists"] for r in link_rows),
        "historical_copied_literal_links_unavailable":sum(not r["Copied literal target exists"] for r in link_rows),
        "historical_link_policy":"Snapshots remain byte-exact. Link map identifies source and collected targets; no originals rewritten.",
        "manifest_missing_files":missing_manifest_files,"tracked_diff_paths":diff_names,"new_files_outside_collection":outside_new,
        "tracked_source_provenance_errors":manifest_provenance_errors,"unknown_requirement_ids":requirement_errors,"generated_hash_errors":generated_hash_errors,
        "ignored_collection_files":ignored,"stage_specific_evidence_checks":anchors,"master_status_counts":master_counts,
        "copied_category_counts":dict(collections.Counter(pathlib.PurePosixPath(r["New path"]).parts[3] for r in copies))}
    write_json(RESULT,result)
    result["directory_files"]=len(expected)
    result["directory_bytes"]=sum(p.stat().st_size for p in OUT.rglob("*") if p.is_file())
    # Size is reported on stdout instead of embedding a circular byte count in itself.
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if not passed: raise SystemExit(1)

if __name__=="__main__":main()
